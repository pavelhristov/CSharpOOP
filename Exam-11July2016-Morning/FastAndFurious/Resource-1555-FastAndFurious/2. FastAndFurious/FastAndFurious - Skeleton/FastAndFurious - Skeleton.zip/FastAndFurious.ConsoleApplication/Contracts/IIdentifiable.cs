﻿namespace FastAndFurious.ConsoleApplication.Contracts
{
   public interface IIdentifiable
   {
      int Id { get; }
   }
}
