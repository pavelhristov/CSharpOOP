﻿namespace FastAndFurious.ConsoleApplication.Common.Enums
{
    public enum TransmissionType
    {
        NotSet = 0,
        ManualShortShifter,
        SemiManualShifter,
        StockShifter
    }
}
