﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dealership.Models
{
    public class VeryImportant
    {
        // Take a break once in awhile :)
        string url = "http://9gag.com";
    }
}
